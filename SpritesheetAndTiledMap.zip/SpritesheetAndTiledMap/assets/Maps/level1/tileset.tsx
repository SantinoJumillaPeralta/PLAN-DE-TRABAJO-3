<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tileset" tilewidth="70" tileheight="70" tilecount="49" columns="7">
 <image source="sheet.png" width="512" height="512"/>
</tileset>
