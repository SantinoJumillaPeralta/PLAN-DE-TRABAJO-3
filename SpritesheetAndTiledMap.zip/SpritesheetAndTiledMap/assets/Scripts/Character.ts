import {
    _decorator,
    Component,
    Node,
    Animation,
    Collider2D,
    RigidBody2D,
    Contact2DType,
    IPhysics2DContact,
    Layers,
    Vec2,
    Vec3,
    input,
    Input,
    EventKeyboard,
    KeyCode,
    Button,
    EventHandler,
    director,
    tween
} from 'cc';

const { ccclass, property } = _decorator;

@ccclass('Character')
export class Character extends Component {

    private gravity: number = -450;
    private jumpForce: number = 400;
    private autoSpeed: number = 100;

    private velocity: Vec2 = new Vec2(0, 0);

    private collider: Collider2D = null;
    private onFloor: boolean = false;
    private colliderCount: number = 0;
    private wallCollider: boolean = false;
    private wallSide: number = 0;

    private currentAnim: string = 'jump';
    private animacion: Animation = null;

    @property({ type: Node, tooltip: 'Arrastra aqu� la c�mara para que siga al personaje' })
    public cameraNode: Node = null;

    @property({ type: Button, tooltip: 'Bot�n para subir' })
    public btnUp: Button = null;

    @property({ type: Button, tooltip: 'Bot�n para bajar' })
    public btnDown: Button = null;

    @property({ type: Node, tooltip: 'Nodo opcional de Game Over para mostrar cuando toque un obst�culo' })
    public gameOverNode: Node = null;

    @property({ type: [Node], tooltip: 'Arrastra aqu� los obst�culos con RigidBody2D' })
    public obstacles: Node[] = [];

    @property({ type: [Node], tooltip: 'Arrastra aqu� los eventos con RigidBody2D' })
    public events: Node[] = [];

    @property({ type: [Node], tooltip: 'Arrastra aqu� las latas de at�n' })
    public tunaCans: Node[] = [];

    @property({ type: [Node], tooltip: 'Arrastra aqu� las comidas' })
    public foods: Node[] = [];

    @property({ type: [Node], tooltip: 'Arrastra aqu� los bidones de leche' })
    public milkBottles: Node[] = [];

    @property({ type: [Node], tooltip: 'Arrastra aqu� el objeto que activa el im�n' })
    public magnetItems: Node[] = [];

    @property({ tooltip: 'Cantidad de comidas necesarias para activar el im�n' })
    public magnetFoodThreshold: number = 3;

    @property({ tooltip: 'Tiempo que dura activo el im�n' })
    public magnetDuration: number = 4.0;

    @property({ tooltip: 'Distancia a la que el im�n empieza a atraer latas' })
    public magnetRadius: number = 350.0;

    private foodCount: number = 0;
    private magnetActive: boolean = false;
    private magnetTimer: number = 0;
    private attractedTunas: Set<Node> = new Set();

    onLoad(): void {
        this.collider = this.getComponent(Collider2D);
        if (this.collider) {
            this.collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
            this.collider.on(Contact2DType.END_CONTACT, this.onEndContact, this);
        }

        this.animacion = this.getComponent(Animation);

        input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
        input.on(Input.EventType.KEY_UP, this.onKeyUp, this);

        if (this.btnUp) {
            const upHandler = new EventHandler();
            upHandler.target = this.node;
            upHandler.component = 'Character';
            upHandler.handler = 'moveUp';
            this.btnUp.clickEvents.push(upHandler);
        }

        if (this.btnDown) {
            const downHandler = new EventHandler();
            downHandler.target = this.node;
            downHandler.component = 'Character';
            downHandler.handler = 'moveDown';
            this.btnDown.clickEvents.push(downHandler);
        }
    }

    onDestroy(): void {
        if (this.collider) {
            this.collider.off(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
            this.collider.off(Contact2DType.END_CONTACT, this.onEndContact, this);
        }

        input.off(Input.EventType.KEY_DOWN, this.onKeyDown, this);
        input.off(Input.EventType.KEY_UP, this.onKeyUp, this);
    }

    private isInList(node: Node, list: Node[]): boolean {
        return list.includes(node);
    }

    private hasRigidBody(node: Node): boolean {
        return !!node.getComponent(RigidBody2D);
    }

    onBeginContact(self: Collider2D, other: Collider2D, contact: IPhysics2DContact | null): void {
        const linkedObject = this.hasRigidBody(other.node);

        if (linkedObject && this.isInList(other.node, this.obstacles)) {
            this.onObstacleHit();
            return;
        }

        if (linkedObject && this.isInList(other.node, this.events)) {
            other.node.destroy();
            return;
        }

        if (linkedObject && this.isInList(other.node, this.tunaCans)) {
            if (this.magnetActive) {
                other.node.destroy();
            }
            return;
        }

        if (linkedObject && this.isInList(other.node, this.foods)) {
            other.node.destroy();
            this.foodCount++;

            if (this.foodCount >= this.magnetFoodThreshold) {
                this.activateMagnet();
            }
            return;
        }

        if (linkedObject && this.isInList(other.node, this.milkBottles)) {
            other.node.destroy();
            return;
        }

        if (linkedObject && this.isInList(other.node, this.magnetItems)) {
            other.node.destroy();
            this.activateMagnet();
            return;
        }

        if (other.node.name === "Enemy") {
        }

        if (other.node.layer === Layers.Enum['Suelo']) {
            this.colliderCount++;
            this.ControlCollisionMap(contact);
        }
    }

    onEndContact(self: Collider2D, other: Collider2D, contact: IPhysics2DContact | null): void {
        this.colliderCount--;
        if (this.colliderCount <= 0) {
            this.colliderCount = 0;
            this.onFloor = false;
            this.wallCollider = false;
        }
    }

    onKeyDown(event: EventKeyboard): void {
        switch (event.keyCode) {
            case KeyCode.SPACE:
                this.Jump();
                break;
        }
    }

    onKeyUp(event: EventKeyboard): void {
        switch (event.keyCode) {
            case KeyCode.SPACE:
                break;
        }
    }

    moveUp(): void {
        this.velocity.y = this.jumpForce;
        this.onFloor = false;
    }

    moveDown(): void {
        this.velocity.y = -this.jumpForce;
        this.onFloor = false;
    }

    changeAnimation(anim: string): void {
        if (this.currentAnim === anim) return;

        this.animacion.play(anim);
        this.currentAnim = anim;
    }

    updateAnimation(): void {
        if (this.onFloor && this.velocity.x === 0) {
            this.changeAnimation("idle");
            return;
        } else if (!this.onFloor) {
            this.changeAnimation("jump");
            return;
        } else if (this.onFloor && this.velocity.x !== 0) {
            this.changeAnimation("walk");
            return;
        }
    }

    start(): void {
        this.node.setScale(1, 1, 1);
        this.changeAnimation("jump");
    }

    update(deltaTime: number): void {
        this.velocity.x = this.autoSpeed;

        if (this.cameraNode) {
            const camPos = this.cameraNode.position;
            this.cameraNode.setPosition(this.node.position.x, camPos.y, camPos.z);
        }

        if (this.magnetActive) {
            this.magnetTimer += deltaTime;

            if (this.magnetTimer >= this.magnetDuration) {
                this.magnetActive = false;
                this.magnetTimer = 0;
                this.attractedTunas.clear();
            } else {
                this.pullNearbyTunas();
            }
        }

        (!this.onFloor) ? this.velocity.y += this.gravity * deltaTime : this.velocity.y = 0;

        let move = new Vec3(this.velocity.x * deltaTime, this.velocity.y * deltaTime, 0);

        if (this.wallCollider && (move.x * this.wallSide > 0)) move.x = 0;

        this.node.setPosition(this.node.position.add(move));

        this.updateAnimation();
    }

    Jump(): void {
        if (this.onFloor) {
            this.velocity.y = this.jumpForce;
            this.onFloor = false;
            this.colliderCount = 0;
            this.changeAnimation("jump");
        }
    }

    private onObstacleHit(): void {

        if (this.gameOverNode) {
            this.gameOverNode.active = true;
        }
        director.pause();
    }

    private activateMagnet(): void {
        this.magnetActive = true;
        this.magnetTimer = 0;
    }

    private pullNearbyTunas(): void {
        const playerPos = this.node.position;

        for (const tuna of this.tunaCans) {
            if (!tuna || !tuna.isValid) continue;
            if (this.attractedTunas.has(tuna)) continue;

            const dist = Vec3.distance(playerPos, tuna.position);
            if (dist > this.magnetRadius) continue;

            this.attractedTunas.add(tuna);

            tween(tuna)
                .to(0.25, { position: new Vec3(playerPos.x, playerPos.y, tuna.position.z) }, { easing: 'quadOut' })
                .call(() => {
                    if (tuna && tuna.isValid) {
                        tuna.destroy();
                    }
                    this.attractedTunas.delete(tuna);
                })
                .start();
        }
    }

    ControlCollisionMap(contact: IPhysics2DContact | null): void {

        if (contact) {
            const worldManifold = contact.getWorldManifold();
            const normal = worldManifold.normal;
            console.log(normal);

            if (Math.abs(normal.y) > 0.7) {
                this.onFloor = true;
                this.velocity.y = 0;
            } else if (Math.abs(normal.x) > 0.7) {
                this.velocity.x = 0;
                this.wallCollider = true;
                this.wallSide = normal.x > 0 ? 1 : -1;

                this.node.setPosition(this.node.position.x + this.wallSide, this.node.position.y, 0);
            }
        }
    }
}