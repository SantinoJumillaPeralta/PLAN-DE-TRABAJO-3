System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Animation, Collider2D, RigidBody2D, Contact2DType, Layers, Vec2, Vec3, input, Input, KeyCode, Button, EventHandler, director, tween, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _crd, ccclass, property, Character;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Animation = _cc.Animation;
      Collider2D = _cc.Collider2D;
      RigidBody2D = _cc.RigidBody2D;
      Contact2DType = _cc.Contact2DType;
      Layers = _cc.Layers;
      Vec2 = _cc.Vec2;
      Vec3 = _cc.Vec3;
      input = _cc.input;
      Input = _cc.Input;
      KeyCode = _cc.KeyCode;
      Button = _cc.Button;
      EventHandler = _cc.EventHandler;
      director = _cc.director;
      tween = _cc.tween;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "98595HnmP1EmacIgJU6kt/U", "Character", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Animation', 'Collider2D', 'RigidBody2D', 'Contact2DType', 'IPhysics2DContact', 'Layers', 'Vec2', 'Vec3', 'input', 'Input', 'EventKeyboard', 'KeyCode', 'Button', 'EventHandler', 'director', 'tween']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Character", Character = (_dec = ccclass('Character'), _dec2 = property({
        type: Node,
        tooltip: 'Arrastra aqu� la c�mara para que siga al personaje'
      }), _dec3 = property({
        type: Button,
        tooltip: 'Bot�n para subir'
      }), _dec4 = property({
        type: Button,
        tooltip: 'Bot�n para bajar'
      }), _dec5 = property({
        type: Node,
        tooltip: 'Nodo opcional de Game Over para mostrar cuando toque un obst�culo'
      }), _dec6 = property({
        type: [Node],
        tooltip: 'Arrastra aqu� los obst�culos con RigidBody2D'
      }), _dec7 = property({
        type: [Node],
        tooltip: 'Arrastra aqu� los eventos con RigidBody2D'
      }), _dec8 = property({
        type: [Node],
        tooltip: 'Arrastra aqu� las latas de at�n'
      }), _dec9 = property({
        type: [Node],
        tooltip: 'Arrastra aqu� las comidas'
      }), _dec10 = property({
        type: [Node],
        tooltip: 'Arrastra aqu� los bidones de leche'
      }), _dec11 = property({
        type: [Node],
        tooltip: 'Arrastra aqu� el objeto que activa el im�n'
      }), _dec12 = property({
        tooltip: 'Cantidad de comidas necesarias para activar el im�n'
      }), _dec13 = property({
        tooltip: 'Tiempo que dura activo el im�n'
      }), _dec14 = property({
        tooltip: 'Distancia a la que el im�n empieza a atraer latas'
      }), _dec(_class = (_class2 = class Character extends Component {
        constructor() {
          super(...arguments);
          this.gravity = -450;
          this.jumpForce = 400;
          this.autoSpeed = 100;
          this.velocity = new Vec2(0, 0);
          this.collider = null;
          this.onFloor = false;
          this.colliderCount = 0;
          this.wallCollider = false;
          this.wallSide = 0;
          this.currentAnim = 'jump';
          this.animacion = null;

          _initializerDefineProperty(this, "cameraNode", _descriptor, this);

          _initializerDefineProperty(this, "btnUp", _descriptor2, this);

          _initializerDefineProperty(this, "btnDown", _descriptor3, this);

          _initializerDefineProperty(this, "gameOverNode", _descriptor4, this);

          _initializerDefineProperty(this, "obstacles", _descriptor5, this);

          _initializerDefineProperty(this, "events", _descriptor6, this);

          _initializerDefineProperty(this, "tunaCans", _descriptor7, this);

          _initializerDefineProperty(this, "foods", _descriptor8, this);

          _initializerDefineProperty(this, "milkBottles", _descriptor9, this);

          _initializerDefineProperty(this, "magnetItems", _descriptor10, this);

          _initializerDefineProperty(this, "magnetFoodThreshold", _descriptor11, this);

          _initializerDefineProperty(this, "magnetDuration", _descriptor12, this);

          _initializerDefineProperty(this, "magnetRadius", _descriptor13, this);

          this.foodCount = 0;
          this.magnetActive = false;
          this.magnetTimer = 0;
          this.attractedTunas = new Set();
        }

        onLoad() {
          this.collider = this.getComponent(Collider2D);

          if (this.collider) {
            this.collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
            this.collider.on(Contact2DType.END_CONTACT, this.onEndContact, this);
          }

          this.animacion = this.getComponent(Animation);
          input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
          input.on(Input.EventType.KEY_UP, this.onKeyUp, this);

          if (this.btnUp) {
            var upHandler = new EventHandler();
            upHandler.target = this.node;
            upHandler.component = 'Character';
            upHandler.handler = 'moveUp';
            this.btnUp.clickEvents.push(upHandler);
          }

          if (this.btnDown) {
            var downHandler = new EventHandler();
            downHandler.target = this.node;
            downHandler.component = 'Character';
            downHandler.handler = 'moveDown';
            this.btnDown.clickEvents.push(downHandler);
          }
        }

        onDestroy() {
          if (this.collider) {
            this.collider.off(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
            this.collider.off(Contact2DType.END_CONTACT, this.onEndContact, this);
          }

          input.off(Input.EventType.KEY_DOWN, this.onKeyDown, this);
          input.off(Input.EventType.KEY_UP, this.onKeyUp, this);
        }

        isInList(node, list) {
          return list.includes(node);
        }

        hasRigidBody(node) {
          return !!node.getComponent(RigidBody2D);
        }

        onBeginContact(self, other, contact) {
          var linkedObject = this.hasRigidBody(other.node);

          if (linkedObject && this.isInList(other.node, this.obstacles)) {
            this.onObstacleHit();
            return;
          }

          if (linkedObject && this.isInList(other.node, this.events)) {
            other.node.destroy();
            return;
          }

          if (linkedObject && this.isInList(other.node, this.tunaCans)) {
            if (this.magnetActive) {
              other.node.destroy();
            }

            return;
          }

          if (linkedObject && this.isInList(other.node, this.foods)) {
            other.node.destroy();
            this.foodCount++;

            if (this.foodCount >= this.magnetFoodThreshold) {
              this.activateMagnet();
            }

            return;
          }

          if (linkedObject && this.isInList(other.node, this.milkBottles)) {
            other.node.destroy();
            return;
          }

          if (linkedObject && this.isInList(other.node, this.magnetItems)) {
            other.node.destroy();
            this.activateMagnet();
            return;
          }

          if (other.node.name === "Enemy") {}

          if (other.node.layer === Layers.Enum['Suelo']) {
            this.colliderCount++;
            this.ControlCollisionMap(contact);
          }
        }

        onEndContact(self, other, contact) {
          this.colliderCount--;

          if (this.colliderCount <= 0) {
            this.colliderCount = 0;
            this.onFloor = false;
            this.wallCollider = false;
          }
        }

        onKeyDown(event) {
          switch (event.keyCode) {
            case KeyCode.SPACE:
              this.Jump();
              break;
          }
        }

        onKeyUp(event) {
          switch (event.keyCode) {
            case KeyCode.SPACE:
              break;
          }
        }

        moveUp() {
          this.velocity.y = this.jumpForce;
          this.onFloor = false;
        }

        moveDown() {
          this.velocity.y = -this.jumpForce;
          this.onFloor = false;
        }

        changeAnimation(anim) {
          if (this.currentAnim === anim) return;
          this.animacion.play(anim);
          this.currentAnim = anim;
        }

        updateAnimation() {
          if (this.onFloor && this.velocity.x === 0) {
            this.changeAnimation("idle");
            return;
          } else if (!this.onFloor) {
            this.changeAnimation("jump");
            return;
          } else if (this.onFloor && this.velocity.x !== 0) {
            this.changeAnimation("walk");
            return;
          }
        }

        start() {
          this.node.setScale(1, 1, 1);
          this.changeAnimation("jump");
        }

        update(deltaTime) {
          this.velocity.x = this.autoSpeed;

          if (this.cameraNode) {
            var camPos = this.cameraNode.position;
            this.cameraNode.setPosition(this.node.position.x, camPos.y, camPos.z);
          }

          if (this.magnetActive) {
            this.magnetTimer += deltaTime;

            if (this.magnetTimer >= this.magnetDuration) {
              this.magnetActive = false;
              this.magnetTimer = 0;
              this.attractedTunas.clear();
            } else {
              this.pullNearbyTunas();
            }
          }

          !this.onFloor ? this.velocity.y += this.gravity * deltaTime : this.velocity.y = 0;
          var move = new Vec3(this.velocity.x * deltaTime, this.velocity.y * deltaTime, 0);
          if (this.wallCollider && move.x * this.wallSide > 0) move.x = 0;
          this.node.setPosition(this.node.position.add(move));
          this.updateAnimation();
        }

        Jump() {
          if (this.onFloor) {
            this.velocity.y = this.jumpForce;
            this.onFloor = false;
            this.colliderCount = 0;
            this.changeAnimation("jump");
          }
        }

        onObstacleHit() {
          if (this.gameOverNode) {
            this.gameOverNode.active = true;
          }

          director.pause();
        }

        activateMagnet() {
          this.magnetActive = true;
          this.magnetTimer = 0;
        }

        pullNearbyTunas() {
          var _this = this;

          var playerPos = this.node.position;

          var _loop = function _loop(tuna) {
            if (!tuna || !tuna.isValid) return 0; // continue

            if (_this.attractedTunas.has(tuna)) return 0; // continue

            var dist = Vec3.distance(playerPos, tuna.position);
            if (dist > _this.magnetRadius) return 0; // continue

            _this.attractedTunas.add(tuna);

            tween(tuna).to(0.25, {
              position: new Vec3(playerPos.x, playerPos.y, tuna.position.z)
            }, {
              easing: 'quadOut'
            }).call(() => {
              if (tuna && tuna.isValid) {
                tuna.destroy();
              }

              _this.attractedTunas.delete(tuna);
            }).start();
          },
              _ret;

          for (var tuna of this.tunaCans) {
            _ret = _loop(tuna);
            if (_ret === 0) continue;
          }
        }

        ControlCollisionMap(contact) {
          if (contact) {
            var worldManifold = contact.getWorldManifold();
            var normal = worldManifold.normal;
            console.log(normal);

            if (Math.abs(normal.y) > 0.7) {
              this.onFloor = true;
              this.velocity.y = 0;
            } else if (Math.abs(normal.x) > 0.7) {
              this.velocity.x = 0;
              this.wallCollider = true;
              this.wallSide = normal.x > 0 ? 1 : -1;
              this.node.setPosition(this.node.position.x + this.wallSide, this.node.position.y, 0);
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cameraNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnUp", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnDown", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "gameOverNode", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "obstacles", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "events", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "tunaCans", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "foods", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "milkBottles", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "magnetItems", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "magnetFoodThreshold", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 3;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "magnetDuration", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 4.0;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "magnetRadius", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 350.0;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=b15ac38ee9cffe1380b4e07b8f7c142cb17b385d.js.map